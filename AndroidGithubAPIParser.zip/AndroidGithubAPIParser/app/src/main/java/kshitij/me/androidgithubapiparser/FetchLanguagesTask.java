package kshitij.me.androidgithubapiparser;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;



public class FetchLanguagesTask extends AsyncTask<String, Integer, Set> {

    protected String BASE_URL = "https://api.github.com/search/repositories?";
    private HttpURLConnection httpURLConnection;
    private BufferedReader reader;
    private String response;
    protected Set languages;
    public AsyncResponse delegate = null;


    public interface AsyncResponse {
        void processFinish(Set output);
    }

    FetchLanguagesTask(AsyncResponse delegate) {
        this.delegate = delegate;
        MainActivity.getTextView().setVisibility(View.VISIBLE);
        MainActivity.getTextView().setVisibility(View.VISIBLE);
    }

    @Override
    protected Set doInBackground(String... defaultSortParameter) {

        try {


            publishProgress(0);
            final String QUERY_PARAMETER = "q";
            final String SORT_PARAMETER = "sort";
            final String SORT_BY_PARAMETER = "order";

            Uri builtUri = Uri.parse(BASE_URL).buildUpon()
                    .appendQueryParameter(QUERY_PARAMETER, defaultSortParameter[0])
                    .appendQueryParameter(SORT_PARAMETER, defaultSortParameter[1])
                    .appendQueryParameter(SORT_BY_PARAMETER, defaultSortParameter[2])
                    .build();

            URL url = new URL(builtUri.toString());

            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();

            if (inputStream == null) {
                return null;
            }

            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }

            if (buffer.length() == 0) {
                return null;
            }
            response = buffer.toString();

            findLanguages(response);


        } catch (Exception e) {

            Log.i("Exception", e.getMessage());
        }

        return languages;
    }


    @Override
    protected void onPostExecute(Set languages) {
        delegate.processFinish(languages);
    }


    private void findLanguages(String response) {

        languages = new HashSet();
        try {
            JSONObject rootObject = new JSONObject(response);
            JSONArray resultsArray = rootObject.getJSONArray("items");

            for (int i = 0; i < 10; i++) {

                publishProgress(i);
                JSONObject eachRepositoryObject = resultsArray.getJSONObject(i);
                if(!eachRepositoryObject.getString("language").equals("null"))
                languages.add(eachRepositoryObject.getString("language"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {


        MainActivity.getProgressBar().setProgress(values[0]);
        MainActivity.getTextView().setText("Fetching Languages");
    }
}

