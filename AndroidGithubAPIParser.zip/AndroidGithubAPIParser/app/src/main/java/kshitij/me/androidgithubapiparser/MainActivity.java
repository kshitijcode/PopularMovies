package kshitij.me.androidgithubapiparser;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class MainActivity extends AppCompatActivity {

    GridView gvRepoInfo;
    RepositoryDisplayAdapter repositoryDisplayAdapter;
    RepositoryInfo repositoryInfo;
    Set fetchedLanguages;
    ArrayList<RepositoryInfo> fetchedRepository;
    Iterator iterator;
    String mCurrentLanguage;
    protected static ProgressBar progressBar;
    protected static TextView textViewProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }


    private void init() {


        gvRepoInfo = (GridView) findViewById(R.id.gvRepositoryInfo);
        fetchedLanguages = new HashSet();
        fetchedRepository = new ArrayList<>();
        repositoryDisplayAdapter = new RepositoryDisplayAdapter(getApplicationContext());
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        textViewProgress = (TextView) findViewById(R.id.textViewProgress);
        startAsyncTaskToFetchLanguages();


    }


    private void startAsyncTaskToFetchLanguages() {
        new FetchLanguagesTask(new FetchLanguagesTask.AsyncResponse() {
            @Override
            public void processFinish(Set languages) {
                fetchedLanguages = languages;
                iterator = fetchedLanguages.iterator();
                while (iterator.hasNext()) {
                    mCurrentLanguage = iterator.next().toString();
                    new FetchRepoTask(new FetchRepoTask.AsyncResponse() {
                        @Override
                        public void processFinish(ArrayList<RepositoryInfo> repo) {

                            fetchedRepository = repo;

                            for (int i = 0; i < fetchedRepository.size(); i++) {
                                addRepositoryInformation(i);
                            }

                        }
                    }).execute("language:" + mCurrentLanguage, "stars", "desc", mCurrentLanguage);
                }
            }
        }).execute("stars:>=1", "stars", "desc");
        gvRepoInfo.setAdapter(repositoryDisplayAdapter);
    }


    private void addRepositoryInformation(int i) {
        if (i == 0) {
            repositoryInfo = new RepositoryInfo();
            repositoryInfo.setmLanguage(fetchedRepository.get(i).getmLanguage());
            repositoryInfo.setmRepostries(fetchedRepository.get(i).getmRepostries());
            repositoryInfo.setIsHeader(true);
            repositoryDisplayAdapter.addHeaderItem(repositoryInfo);
        } else {
            repositoryInfo = new RepositoryInfo();
            repositoryInfo.setmRepostries(fetchedRepository.get(i).getmRepostries());
            repositoryInfo.setIsHeader(false);
            repositoryDisplayAdapter.addItem(repositoryInfo);
        }
    }


    public static ProgressBar getProgressBar() {
        return progressBar;
    }

    public static TextView getTextView() {
        return textViewProgress;
    }
}
