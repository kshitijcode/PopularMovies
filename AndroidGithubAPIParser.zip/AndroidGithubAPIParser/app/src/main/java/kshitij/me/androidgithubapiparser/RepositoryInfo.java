package kshitij.me.androidgithubapiparser;

public class RepositoryInfo {


    protected String mLanguage;
    protected String mRepostries;
    protected boolean isHeader;

    public boolean isHeader() {
        return isHeader;
    }

    public void setIsHeader(boolean isHeader) {
        this.isHeader = isHeader;
    }

    public String getmLanguage() {
        return mLanguage;
    }

    public void setmLanguage(String mLanguage) {
        this.mLanguage = mLanguage;
    }


    public String getmRepostries() {
        return mRepostries;
    }

    public void setmRepostries(String mRepostries) {
        this.mRepostries = mRepostries;
    }


}
