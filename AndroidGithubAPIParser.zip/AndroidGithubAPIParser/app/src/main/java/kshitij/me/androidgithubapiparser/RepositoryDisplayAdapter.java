package kshitij.me.androidgithubapiparser;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class RepositoryDisplayAdapter extends BaseAdapter {

    private static final int TYPE_ITEM = 0;
    private static final int TYPE_HEADER = 1;
    protected ViewHolder holder;


    private ArrayList<RepositoryInfo> mRepostitoryData;
    private LayoutInflater mInflater;

    public RepositoryDisplayAdapter(Context context) {
        mInflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mRepostitoryData = new ArrayList<RepositoryInfo>();
    }

    public void addItem(final RepositoryInfo repositoryInfo) {
        mRepostitoryData.add(repositoryInfo);
        notifyDataSetChanged();
    }

    public void addHeaderItem(final RepositoryInfo repositoryInfo) {
        mRepostitoryData.add(repositoryInfo);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return mRepostitoryData.get(position).isHeader() ? TYPE_HEADER : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getCount() {
        return mRepostitoryData.size();
    }

    @Override
    public RepositoryInfo getItem(int position) {
        return mRepostitoryData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        int rowType = getItemViewType(position);


        if (convertView == null) {

            switch (rowType) {
                case TYPE_HEADER:
                    convertView = mInflater.inflate(R.layout.gv_language_layout, parent, false);
                    holder = new ViewHolder();
                    holder.textView = (TextView) convertView.findViewById(R.id.tvLanguage);
                    convertView.setTag(holder);
                case TYPE_ITEM:
                    convertView = mInflater.inflate(R.layout.gv_repository_layout, parent, false);
                    holder = new ViewHolder();
                    holder.textView = (TextView) convertView.findViewById(R.id.tvRepository);
                    convertView.setTag(holder);
            }


        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        if (rowType == TYPE_HEADER) {
            holder.textView.setTextColor(Color.BLUE);
            holder.textView.setText(mRepostitoryData.get(position).getmLanguage());
        } else {
            holder.textView.setText(mRepostitoryData.get(position).getmRepostries());
        }
        return convertView;
    }


    public static class ViewHolder {
        public TextView textView;
    }


}

